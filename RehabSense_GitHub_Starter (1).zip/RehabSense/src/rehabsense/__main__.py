import argparse
import json
from pathlib import Path

from .analysis import load_imu_csv, process_imu, detect_steps, summarize_gait
from .plots import save_gait_plot


def main():
    parser = argparse.ArgumentParser(description="Analyze wearable IMU gait data.")
    parser.add_argument("--input", required=True, help="Path to IMU CSV file")
    parser.add_argument("--output", default="outputs", help="Output directory")
    parser.add_argument("--threshold", type=float, default=0.035, help="Peak threshold in g")
    args = parser.parse_args()

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    raw = load_imu_csv(args.input)
    processed = process_imu(raw)
    steps = detect_steps(processed, threshold_g=args.threshold)
    summary = summarize_gait(processed, steps)

    save_gait_plot(processed, steps, out / "gait_analysis.png")
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(f"\\nSaved plot and summary to: {out.resolve()}")


if __name__ == "__main__":
    main()
