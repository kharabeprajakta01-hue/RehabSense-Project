import numpy as np
import pandas as pd
from rehabsense.analysis import process_imu, detect_steps, summarize_gait


def test_processing_adds_signal_columns():
    t = np.arange(0, 5, 0.02)
    pulse = 0.12 * np.maximum(0, np.sin(2 * np.pi * 1.8 * t)) ** 8
    frame = pd.DataFrame({
        "timestamp_s": t, "ax_g": pulse, "ay_g": np.zeros_like(t),
        "az_g": np.ones_like(t), "gx_dps": np.zeros_like(t),
        "gy_dps": np.zeros_like(t), "gz_dps": np.zeros_like(t)
    })
    processed = process_imu(frame)
    assert "dynamic_accel_smooth_g" in processed.columns
    assert len(processed) == len(frame)


def test_summary_handles_no_steps():
    t = np.arange(0, 2, 0.02)
    frame = pd.DataFrame({
        "timestamp_s": t, "dynamic_accel_smooth_g": np.zeros_like(t)
    })
    summary = summarize_gait(frame, np.array([], dtype=int))
    assert summary["detected_step_events"] == 0
    assert summary["mean_step_interval_s"] is None
