#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

Adafruit_MPU6050 mpu;
const unsigned long SAMPLE_PERIOD_MS = 20; // approximately 50 Hz
unsigned long lastSample = 0;

void setup() {
  Serial.begin(115200);
  Wire.begin();

  if (!mpu.begin()) {
    Serial.println("# ERROR: MPU6050 not detected. Check wiring.");
    while (true) delay(100);
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  // CSV header; capture this serial stream to a .csv file.
  Serial.println("timestamp_s,ax_g,ay_g,az_g,gx_dps,gy_dps,gz_dps");
}

void loop() {
  unsigned long now = millis();
  if (now - lastSample >= SAMPLE_PERIOD_MS) {
    lastSample = now;

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    // Adafruit reports acceleration in m/s^2 and gyro in rad/s.
    const float ms2_to_g = 1.0 / 9.80665;
    const float rad_to_deg = 180.0 / PI;

    Serial.print(now / 1000.0, 3); Serial.print(",");
    Serial.print(a.acceleration.x * ms2_to_g, 5); Serial.print(",");
    Serial.print(a.acceleration.y * ms2_to_g, 5); Serial.print(",");
    Serial.print(a.acceleration.z * ms2_to_g, 5); Serial.print(",");
    Serial.print(g.gyro.x * rad_to_deg, 3); Serial.print(",");
    Serial.print(g.gyro.y * rad_to_deg, 3); Serial.print(",");
    Serial.println(g.gyro.z * rad_to_deg, 3);
  }
}
