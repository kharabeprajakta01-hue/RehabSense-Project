# RehabSense: Wearable IMU-Based Gait Monitoring

**A research-oriented biomedical instrumentation prototype for movement monitoring and rehabilitation support.**

RehabSense demonstrates an end-to-end workflow for collecting inertial measurement unit (IMU) data, processing motion signals, estimating basic walking metrics, and visualizing movement patterns.

## Why this project?

The project connects:
- Biomedical instrumentation and wearable sensing
- Embedded systems (ESP32 + MPU6050)
- Signal processing and Python data analysis
- Movement biomechanics and rehabilitation technology

It is designed as a portfolio/research-prototype project, not a clinically validated diagnostic device.

## Features

- Reads timestamped accelerometer and gyroscope CSV data
- Removes gravity using a simple high-pass filtering approach
- Calculates acceleration magnitude and smooths the signal
- Estimates step events using peak detection
- Reports estimated cadence and step intervals
- Creates plots for acceleration and detected steps
- Includes an optional ESP32 + MPU6050 Arduino data-logging sketch
- Includes synthetic sample data so the software can be tested without hardware

> **Important:** Step detection is a simple demonstration algorithm. Sensor placement, calibration, walking speed, individual gait patterns, and noise affect accuracy. Do not use the output for diagnosis, treatment decisions, or unsupervised clinical care.

## Hardware (optional)

- ESP32 development board
- MPU6050 6-axis accelerometer/gyroscope module
- Jumper wires
- USB cable
- Optional strap/enclosure to attach the sensor securely to the lower leg

### Example wiring (ESP32)

| MPU6050 | ESP32 |
|---|---|
| VCC | 3V3 |
| GND | GND |
| SDA | GPIO 21 |
| SCL | GPIO 22 |

Check the pinout and voltage requirements of your specific board and sensor breakout before connecting.

## Install

Python 3.10 or newer is recommended.

```bash
git clone https://github.com/YOUR-USERNAME/RehabSense.git
cd RehabSense
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## Run the analysis

```bash
python -m rehabsense --input data/sample_gait.csv --output outputs
```

If running from the repository root, set the package path first:

```bash
# Windows PowerShell
$env:PYTHONPATH="src"
# macOS/Linux
export PYTHONPATH=src
python -m rehabsense --input data/sample_gait.csv --output outputs
```

The program creates:
- `outputs/gait_analysis.png` — acceleration magnitude and detected step events
- `outputs/summary.json` — estimated cadence, step count, and interval statistics

## Input CSV format

Required columns:

```text
timestamp_s,ax_g,ay_g,az_g,gx_dps,gy_dps,gz_dps
```

- `timestamp_s`: elapsed time in seconds
- `ax_g`, `ay_g`, `az_g`: acceleration in g
- `gx_dps`, `gy_dps`, `gz_dps`: angular velocity in degrees/second

The included sample data is synthetic and is not human-subject data.

## Firmware

Open `firmware/esp32_mpu6050/esp32_mpu6050.ino` in Arduino IDE. Install the **Adafruit MPU6050** and **Adafruit Unified Sensor** libraries, select your ESP32 board, and upload.

The sketch streams CSV rows over Serial at 50 Hz. Capture the serial output to a CSV file, add the header shown above, and pass it to the Python analysis pipeline. Sensor calibration and mounting orientation should be documented for any real experiment.

## Research extensions

1. Compare sensor placement at the waist, ankle, and foot.
2. Add calibration and orientation estimation.
3. Evaluate step detection against manually labelled walking trials.
4. Investigate gait variability across repeated trials.
5. Add bilateral sensors to explore left-right timing differences.
6. Design a safe, consent-based protocol with supervisor approval before collecting human-subject data.

## Limitations and responsible use

- This is an educational engineering prototype, not a medical device.
- It does not diagnose gait disorders or prescribe rehabilitation.
- The basic algorithm may produce false or missed steps.
- Do not collect identifiable human movement data without informed consent and required institutional approvals.
- Store and share only data you have permission to use.

## Suggested GitHub description

`Wearable IMU-based gait monitoring prototype using ESP32/MPU6050, Python signal processing, step-event estimation and movement visualization.`

## Suggested topics

`biomedical-engineering` `wearable-sensors` `imu` `gait-analysis` `rehabilitation-technology` `biomechanics` `embedded-systems` `esp32` `signal-processing` `mpu6050`
