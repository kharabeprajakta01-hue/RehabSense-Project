"""Basic signal processing and gait-event estimation for IMU recordings."""
from __future__ import annotations

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ["timestamp_s", "ax_g", "ay_g", "az_g", "gx_dps", "gy_dps", "gz_dps"]


def load_imu_csv(path: str) -> pd.DataFrame:
    """Load and validate an IMU CSV file."""
    frame = pd.read_csv(path)
    missing = [column for column in REQUIRED_COLUMNS if column not in frame.columns]
    if missing:
        raise ValueError(f"Missing required CSV columns: {', '.join(missing)}")
    frame = frame[REQUIRED_COLUMNS].apply(pd.to_numeric, errors="coerce").dropna()
    frame = frame.sort_values("timestamp_s").drop_duplicates("timestamp_s")
    if len(frame) < 10:
        raise ValueError("At least 10 valid samples are required.")
    if (np.diff(frame["timestamp_s"]) <= 0).any():
        raise ValueError("Timestamps must increase.")
    return frame.reset_index(drop=True)


def moving_average(values: np.ndarray, window: int = 5) -> np.ndarray:
    """Centered moving average with edge handling."""
    if window < 1:
        raise ValueError("window must be >= 1")
    if window == 1:
        return np.asarray(values, dtype=float)
    return pd.Series(values).rolling(window, center=True, min_periods=1).mean().to_numpy()


def process_imu(frame: pd.DataFrame) -> pd.DataFrame:
    """Add acceleration magnitude and a smoothed dynamic component.

    A simple mean-removal baseline is used for demonstration. It is not a
    substitute for calibrated gravity/orientation estimation.
    """
    result = frame.copy()
    xyz = result[["ax_g", "ay_g", "az_g"]].to_numpy(dtype=float)
    magnitude = np.linalg.norm(xyz, axis=1)
    dynamic = magnitude - moving_average(magnitude, window=51)
    result["accel_magnitude_g"] = magnitude
    result["dynamic_accel_g"] = dynamic
    result["dynamic_accel_smooth_g"] = moving_average(dynamic, window=5)
    return result


def detect_steps(processed: pd.DataFrame, min_interval_s: float = 0.30,
                 threshold_g: float = 0.035) -> np.ndarray:
    """Detect candidate step peaks using threshold + local maxima.

    This intentionally simple detector is a starting point for validation,
    not a clinically validated gait-event detector.
    """
    signal = processed["dynamic_accel_smooth_g"].to_numpy()
    times = processed["timestamp_s"].to_numpy()
    peaks = []
    last_time = -np.inf
    for i in range(1, len(signal) - 1):
        is_peak = signal[i] >= threshold_g and signal[i] > signal[i - 1] and signal[i] >= signal[i + 1]
        if is_peak and times[i] - last_time >= min_interval_s:
            peaks.append(i)
            last_time = times[i]
    return np.asarray(peaks, dtype=int)


def summarize_gait(processed: pd.DataFrame, step_indices: np.ndarray) -> dict:
    """Return transparent, descriptive estimates from detected step events."""
    step_times = processed["timestamp_s"].to_numpy()[step_indices]
    intervals = np.diff(step_times)
    duration = float(processed["timestamp_s"].iloc[-1] - processed["timestamp_s"].iloc[0])
    cadence = (len(step_times) / duration * 60.0) if duration > 0 else 0.0
    return {
        "recording_duration_s": round(duration, 3),
        "detected_step_events": int(len(step_times)),
        "estimated_cadence_steps_per_min": round(float(cadence), 1),
        "mean_step_interval_s": round(float(np.mean(intervals)), 3) if len(intervals) else None,
        "step_interval_std_s": round(float(np.std(intervals)), 3) if len(intervals) else None,
        "interpretation": "Exploratory estimates only; validate against labelled reference data."
    }
