from pathlib import Path
import matplotlib.pyplot as plt


def save_gait_plot(processed, step_indices, output_path):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    times = processed["timestamp_s"]
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(times, processed["accel_magnitude_g"], alpha=0.45, label="Acceleration magnitude")
    ax.plot(times, processed["dynamic_accel_smooth_g"], label="Smoothed dynamic component")
    if len(step_indices):
        ax.scatter(times.iloc[step_indices],
                   processed["dynamic_accel_smooth_g"].iloc[step_indices],
                   marker="x", label="Candidate step events")
    ax.set_title("RehabSense – exploratory gait signal analysis")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Acceleration (g)")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
