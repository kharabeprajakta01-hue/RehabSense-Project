# Contributing

1. Create a branch for each feature.
2. Keep algorithms documented and reproducible.
3. Add tests for signal-processing changes.
4. Clearly distinguish measured results from simulated data.
5. Never commit identifiable participant data or data collected without permission.
